package view.messages;

import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;

public class CodeReturnMail extends AbstractCodeReturnMail {

	public CodeReturnMail(List<Integer> codes, Logger logger) {
		super();
		super.setCodes(codes);
		super.setLogger(logger);
		super.setUnknown(false);
		super.setMessage(new MessageMail(logger));
		super.setMessageError(new MessageErrorMail(logger));
	}

	/**
	 * @param logger
	 * 
	 */
	public void codesTranslation() {
		Iterator<Integer> it;
		boolean error;
		int code;

		error = false;
		it = super.codes.iterator();

		// Translation of the return codes into messages
		while (it.hasNext()) {
			code = it.next();

			if (code < 100) {
				// Error during the process detected
				super.messageError.setCode(code);
				error = true;
			} else {
				super.message.setCode(code);
			}

			codeTranslation(code);
		}

		if (error == true) {
			// The program terminated abnormally
			super.messageError.abnormalEnd();
		} else {
			// The program terminated normally
			normalTerminatedMessage();
		}

	}

	/**
	 * Code between 100 and 109 correspond to normal end if there is no error before
	 */
	private void normalTerminatedMessage() {
		int nb;
		boolean end;

		if (super.Unknown == false) { // An unknown code detected does not do a normal ending

			nb = 109;

			do {
				end = false;

				if (super.codes.contains(nb)) {
					end = true;
					super.message.noProblem();
				} else if (nb < 100) {
					end = true;
				} else {
					nb--;
				}

			} while (end == false);

		}

	}// -

	/**
	 * Translate the code
	 * 
	 * @param code
	 */
	private void codeTranslation(int code) {

		switch (code) {
		// **************
		// NORMAL CODES
		// -------------
		case 100:
			break;

		// **********
		// WARNINGS
		// ----------
		// DATE & TIME :
		case 110:
			super.message.problemFormatDate();
			break;

		case 111:
			super.message.problemCreationDate();
			break;

		case 115:
			super.message.instantEmpty();
			break;

		case 116:
			super.message.timeZoneNotFound();
			break;

		case 118:
			super.message.ProblemTimeChronometer();
			break;

		// ********
		// ERRORS
		// --------
		// SOCKET :
		case 11:
			super.messageError.problemOpenSocket();
			break;

		case 12:
			super.messageError.problemInputStreamSocket();
			break;

		case 13:
			super.messageError.problemClosingSocket();
			break;

		case 14:
			super.messageError.problemReadingFlux();
			break;

		case 15:
			super.messageError.socketException();
			break;

		case 16:
			super.messageError.IOexception();
			break;

		case 17:
			super.messageError.IOProblemWritingFlux();
			break;

		case 18:
			super.messageError.problemWritingFlux();
			break;
			
		case 19:
			super.messageError.problemTerminatingSocket();
			break;

		// FILE :
		case 20:
			super.messageError.problemExistFileIn();
			break;

		case 21:
			super.messageError.contentEmpty();
			break;

		case 22:
			super.messageError.problemReadFileIn();
			break;

		case 25:
			super.messageError.nothingToWrite();
			break;

		case 26:
			super.messageError.problemCreateFileOut();
			break;

		case 27:
			super.messageError.problemWriting();
			break;

		// URL :
		case 30:
			super.messageError.problemURL();
			break;

		case 31:
			super.messageError.blankURL();
			break;

		case 35:
			super.messageError.unknowHost();
			break;

		case 36:
			super.messageError.problemHost();
			break;

		// UTF8 :
		case 50:
			super.messageError.unknownEncoding();
			break;

		case 51:
			super.messageError.problemEncoding();
			break;

		// UNKNOWN CODE :
		default:
			super.Unknown = true;
			super.messageError.unknownCode();
		}

	}

}// END PRG
