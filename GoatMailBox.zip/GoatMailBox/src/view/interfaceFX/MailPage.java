package view.interfaceFX;

import java.io.IOException;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import mailBoxGoat.MainBoxGoat;

public class MailPage {
	private static String blank = "";

	@FXML
	private TextField textAddressee;

	@FXML
	private TextField textMessage;

	@FXML
	private TextField textObject;

	@FXML
	private Label labelInfo;

	/**
	 * 
	 * @param primaryStage
	 * @return Scene
	 * @throws Exception
	 */
	public Scene getScene() throws Exception {
		Parent root;
		Scene scene;

		root = FXMLLoader.load(getClass().getResource("mail.fxml"));
		scene = new Scene(root);

		return scene;
	}

	/**
	 * 
	 * @throws IOException
	 */
	public void displayWindows() throws IOException {
		Parent root;
		Scene scene;
		Stage stage;

		root = FXMLLoader.load(getClass().getResource("mail.fxml"));
		scene = new Scene(root);

		stage = new Stage();
		stage.setScene(scene);

		stage.show();
	}

	// ACTIONS
	@FXML
	void resetAll(ActionEvent event) {
		textAddressee.setText(blank);
		textObject.setText(blank);
		textMessage.setText(blank);
	}

	@FXML
	void resetContent(ActionEvent event) {
		textMessage.setText(blank);
	}

	@FXML
	void saveDraft(ActionEvent event) {
		String addressee, object, message;

		addressee = textAddressee.getText();
		object = textObject.getText();
		message = textMessage.getText();

		if (addressee.isBlank() == false) {
			if (object.isBlank() == false) {
				if (message.isEmpty() == false) {
					MainBoxGoat.writeDraft(addressee, object, message);
					labelInfo.setText("Saved as a draft");

				} else {
					labelInfo.setText("The message is empty !");
				}
			} else {
				labelInfo.setText("The mail has no object !");
			}
		} else {
			labelInfo.setText("The adresse field is blank !");
		}

	}

	@FXML
	void sendMessage(ActionEvent event) {
		String addressee, object, message;

		addressee = textAddressee.getText();
		object = textObject.getText();
		message = textMessage.getText();
		labelInfo.setText("");

		if (addressee.isBlank() == false) {
			if (object.isBlank() == false) {
				if (message.isEmpty() == false) {
					MainBoxGoat.writeMessage(addressee, object, message);
					Platform.exit();

				} else {
					labelInfo.setText("The message is empty !");
				}
			} else {
				labelInfo.setText("The mail has no object !");
			}
		} else {
			labelInfo.setText("The adresse field is blank !");
		}
	}

}// END PRG
