package view.interfaceFX;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import mailBoxGoat.MainBoxGoat;

public class WelcomePage {

	public WelcomePage() {
	}

	/**
	 * 
	 * @return Scene
	 * @throws Exception
	 */
	public Scene getScene() throws Exception {
		Parent root;
		Scene scene;

		root = FXMLLoader.load(getClass().getResource("welcomingPage.fxml"));
		scene = new Scene(root);

		return scene;
	}

	// ACTIONS
	@FXML
	void exitProgram(ActionEvent event) {
		Platform.exit();
	}

	@FXML
	void newMessage(ActionEvent event) {
		MailPage mailPage;

		try {
			mailPage = new MailPage();
			mailPage.displayWindows();

		} catch (Exception e) {
			MainBoxGoat.addReturnCode(3);
		}
	}

}// END PRG
