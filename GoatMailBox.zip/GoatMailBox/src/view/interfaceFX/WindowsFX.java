package view.interfaceFX;

import java.io.IOException;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;
import mailBoxGoat.MainBoxGoat;

public class WindowsFX extends Application {

	public void launchwindows(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) {
		IdPwPage idPwPage;

		primaryStage.setOnCloseRequest(e -> closeWindow());
		primaryStage.setResizable(false);
		primaryStage.setTitle("ID page");

		idPwPage = new IdPwPage();
		try {
			primaryStage.setScene(idPwPage.getScene());

		} catch (IOException e) {
			MainBoxGoat.addReturnCode(1);
		} catch (Exception e) {
			MainBoxGoat.addReturnCode(9);
		}

		primaryStage.show();

	}

	private void closeWindow() {
		Platform.exit();
	}

}// END PRG
