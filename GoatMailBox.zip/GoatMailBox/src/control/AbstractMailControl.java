package control;

import java.io.File;

import org.apache.logging.log4j.Logger;

import model.ModelSocketCreation;

public abstract class AbstractMailControl {
	protected ModelSocketCreation socketCreation;
	protected String id, password;
	protected String addressee, object, message, content;
	protected File file;
	protected Logger log;
	protected int returnCode;

	// Getters & Setters
	protected ModelSocketCreation getSocketCreation() {
		return socketCreation;
	}

	protected void setSocketCreation(ModelSocketCreation socketCreation) {
		this.socketCreation = socketCreation;
	}

	public Logger getLog() {
		return log;
	}

	protected void setLog(Logger log) {
		this.log = log;
	}

	public int getReturnCode() {
		return returnCode;
	}

	protected void setReturnCode(int returnCode) {
		this.returnCode = returnCode;
	}

	protected String getId() {
		return id;
	}

	protected void setId(String id) {
		this.id = id;
	}

	protected String getPassword() {
		return password;
	}

	protected void setPassword(String password) {
		this.password = password;
	}

	public String getAddressee() {
		return addressee;
	}

	public void setAddressee(String addressee) {
		this.addressee = addressee;
	}

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	protected File getFile() {
		return file;
	}

	protected void setFile(File file) {
		this.file = file;
	}

}// END PRG
