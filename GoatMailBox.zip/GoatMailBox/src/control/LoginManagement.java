package control;

public class LoginManagement implements Repertory {

	/**
	 * 
	 * @param idLogin
	 * @return boolean
	 */
	public static boolean isLogin(String idLogin) {
		boolean equal;

		equal = false;

		if (idLogin.equals(id)) {
			equal = true;
		}

		return equal;
	}

	/**
	 * 
	 * @param passwordLogin
	 * @return boolean
	 */
	public static boolean isPassword(String passwordLogin) {
		boolean equal;

		equal = false;

		if (passwordLogin.equals(password)) {
			equal = true;
		}

		return equal;
	}

}// END PRG
