package control;

public interface Repertory {
	static final String pathDraft = "C:\\Users\\Pierre\\Desktop\\Projet alpha\\Java\\draft\\draft.txt";
	static final String id = "id";
	static final String password = "pw";
	static final int port = 8080;

}// END PRG
