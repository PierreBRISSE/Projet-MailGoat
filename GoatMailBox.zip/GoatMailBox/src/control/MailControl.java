package control;

import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;

import org.apache.logging.log4j.Logger;

import model.ModelSocketCreation;
import tools.Writing;

public class MailControl extends AbstractMailControl implements Repertory {
	private static MailControl instanceControl = null;
	private static final String separator = "###";

	private MailControl(Logger log, String addressee, String object, String message, String loginID, String loginPW) {
		super();
		super.setReturnCode(100);
		super.setLog(log);
		super.setId(loginID);
		super.setPassword(loginPW);
		super.setAddressee(addressee);
		super.setObject(object);
		super.setMessage(message);
		super.setContent(super.addressee + separator + super.object + separator + super.message + separator + super.id
				+ separator + super.password);
		super.setFile(new File(pathDraft));
	}

	/**
	 * 
	 * @param log
	 * @param adressee
	 * @param object
	 * @param message
	 * @param loginPW
	 * @param loginID
	 * @return instance Control
	 */
	public static MailControl instance(Logger log, String addressee, String object, String message, String loginID,
			String loginPW) {
		if (instanceControl == null) {
			instanceControl = new MailControl(log, addressee, object, message, loginID, loginPW);
		}

		return instanceControl;
	}

	/**
	 * Write the content of the mail in a file to save it temporally
	 * 
	 * @return returnCode
	 */
	public int writingMail() {
		Writing writing;

		super.log.trace("MailGoat - " + MailControl.class + " writing the mail into draft.");

		writing = new Writing(super.content, super.file);
		writing.writingFile();
		super.returnCode = writing.writingFile();

		return super.returnCode;
	}

	/**
	 * 
	 * @return returnCode
	 */
	public int sendMail() {
		String url;

		try {
			super.log.trace("MailGoat - " + MailControl.class + " send mail.");
			url = getURL();
			super.socketCreation = ModelSocketCreation.instanceSocketCreation(pathDraft, port, url, super.content, log);
			super.returnCode = super.socketCreation.getReturnCode();

		} catch (UnknownHostException e) {
			super.returnCode = 35;
		} catch (Exception e) {
			super.returnCode = 36;
		}

		if (super.returnCode > 99) {
			super.socketCreation.start();
			super.returnCode = super.socketCreation.getReturnCode();
		}

		return super.returnCode;
	}

	/**
	 * 
	 * @return url
	 * @throws UnknownHostException
	 */
	private String getURL() throws UnknownHostException {
		String tab[];
		String localHost, url;

		localHost = InetAddress.getLocalHost().toString();
		tab = localHost.split("/");
		url = tab[1];

		return url;
	}

}// END PRG
