package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ModelLoginBase {
	private String loginID, loginPassword;
	private int id;

	public ModelLoginBase() {
	}

	public ModelLoginBase(String loginID, String loginPassword) {
		setLoginID(loginID);
		setLoginPassword(loginPassword);
	}

	// Getters & Setters :
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public String getLoginID() {
		return loginID;
	}

	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}

}// END PRG
