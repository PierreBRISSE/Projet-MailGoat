package model;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;

import org.apache.logging.log4j.Logger;

public class ModelServerSocket extends AbstractModelSocketServer {
	private static ModelServerSocket instanceModelServerSocket = null;

	private ModelServerSocket(int port, InetAddress url, String path, Logger logger, int timeout) {
		super();
		super.setReturnCode(new ArrayList<Integer>());
		super.addReturnCode(100);
		super.setErrorReturnCode(false);
		super.setPort(port);
		super.setUrl(url);
		super.setPath(path);
		super.setTime(timeout);
		super.setLogger(logger);
	}

	/**
	 * 
	 * @param port
	 * @param url
	 * @param path
	 * @param logger
	 * @param timeout
	 * @return ModelServerSocket
	 */
	public static ModelServerSocket getInstanceModelServerSocket(int p, InetAddress url, String path, Logger l, int t) {
		if (instanceModelServerSocket == null) {
			instanceModelServerSocket = new ModelServerSocket(p, url, path, l, t);
		}

		return instanceModelServerSocket;
	}

	/**
	 * Close the socket
	 * 
	 * @return returnCode
	 */
	public void close() {
		super.logger.trace("Sever - " + ModelServerSocket.class + " close");

		try {
			super.socket.close();
			super.serverSocket.close();

		} catch (Exception e) {
			super.addReturnCode(13);
		}

	}

	/**
	 * Start the connection
	 * 
	 * @param logger
	 * 
	 * @return returnCode;
	 */
	public void start() {

		try {
			super.logger.trace("Sever - " + ModelServerSocket.class + " start at port : " + super.port);
			super.logger.trace(" for a duration of " + super.time / 1000 + " s");

			super.serverSocket = new ServerSocket(super.port);
			serverSocket.setSoTimeout(super.time);

		} catch (SocketTimeoutException e) {
			super.addReturnCode(101);
		} catch (SocketException e) {
			super.addReturnCode(15);
		} catch (Exception e) {
			super.addReturnCode(11);
		}

	}

	/**
	 * new communication
	 */
	public void accept() {
		try {
			super.socket = serverSocket.accept();

		} catch (IOException e) {
			super.addReturnCode(16);
		} catch (Exception e) {
			super.addReturnCode(11);
		}

		super.in = null;
	}

	/**
	 * Collect the stream
	 */
	public String read() {
		super.logger.trace(" for a duration of " + super.time / 1000 + " s");

		try (DataInputStream reading = new DataInputStream(super.socket.getInputStream())) {
			super.logger.trace("Sever - " + ModelServerSocket.class + " reading a stream");

			while (reading.available() > 0) {
				super.in += reading.readUTF();
			}

			reading.close();

		} catch (IOException e) {
			super.addReturnCode(12);
		} catch (Exception e) {
			super.addReturnCode(14);
		}

		return super.in;

	}// -

	/**
	 * Send a message
	 */
//	public void message() {
//
//		try (DataOutputStream dataOutputStream = new DataOutputStream(super.socket.getOutputStream())) {
//			super.logger.trace("Sever -" + ModelServerSocket.class + " writing the return message");
//
//			dataOutputStream.writeUTF("confirm");
//			dataOutputStream.flush();
//
//			dataOutputStream.close();
//
//		} catch (IOException e) {
//			super.addReturnCode(17);
//		} catch (Exception e) {
//			super.addReturnCode(18);
//		}
//	}

	/**
	 * Method to use if you want to find a port
	 */
//	public void portAction() {
//		ServerSocket serverSocketPort;
//
//		for (int portTest = 1; portTest <= 65535; portTest++) {
//			try {
//				serverSocketPort = new ServerSocket(portTest);
//			} catch (IOException e) {
//				System.err.println("The port " + portTest + " is already in use ! ");
//			}
//		}
//	} // -

}// END PRG