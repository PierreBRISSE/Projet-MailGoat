package control;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class SessionCreation {

	public static SessionFactory getSessionFactory() {
		MetadataSources sources;
		StandardServiceRegistry registry;
		Metadata metadata;
		SessionFactory sessionFactory;

		registry = new StandardServiceRegistryBuilder().configure().build();
		sources = new MetadataSources(registry);
		metadata = sources.buildMetadata();
		sessionFactory = metadata.buildSessionFactory();

		return sessionFactory;
	}

}// END PRG
