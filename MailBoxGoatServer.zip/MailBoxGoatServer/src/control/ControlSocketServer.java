package control;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;

import model.ModelServerSocket;
import tools.Writing;

public class ControlSocketServer extends AbstractControlSocketServer implements Repertory {
	private static ControlSocketServer instanceContolServerSocket = null;

	private ControlSocketServer(Logger logger) {
		super();
		super.setReturnCode(new ArrayList<Integer>());
		super.addReturnCode(100);
		super.setErrorReturnCode(false);
		super.setCheckLogins(false);
		super.setTexteContent("");
		super.setLogger(logger);
	}

	/**
	 * 
	 * @param logger
	 * @return new ContolServerSocket or null
	 */
	public static ControlSocketServer getInstanceContolServerSocket(Logger logger) {
		if (instanceContolServerSocket == null) {
			instanceContolServerSocket = new ControlSocketServer(logger);
		}

		return instanceContolServerSocket;
	}

	/**
	 * Opening the server
	 * 
	 * @param logger
	 * 
	 * @return returnCode
	 */
	public List<Integer> openServer() {
		super.log.trace("Sever - " + ControlSocketServer.class);

		try {

			super.url = InetAddress.getLocalHost();
			super.modelServerSocket = ModelServerSocket.getInstanceModelServerSocket(port, super.url, path, log,
					timeout);

			if (super.url.toString().isBlank() == false) {
				super.modelServerSocket.start();

				communication();

				super.modelServerSocket.close();

			} else {
				super.addReturnCode(31);
			}

		} catch (UnknownHostException e) {
			super.addReturnCode(35);
		} catch (Exception e) {
			super.addReturnCode(36);
		}

		return super.returnCode;
	}// -

	/**
	 * 
	 * @return url
	 * @throws UnknownHostException
	 */
//	private String getURL() throws UnknownHostException {
//		String tab[];
//		String localHost, url;
//
//		localHost = InetAddress.getLocalHost().toString();
//		tab = localHost.split("/");
//		url = tab[1];
//
//		return url;
//	}

	/**
	 * Main process
	 */
	private void communication() {
		super.log.trace("Sever - Communication");

		super.modelServerSocket.accept();
		super.texteContent = super.modelServerSocket.read();

		// Gathering the return codes from modelServerSocket
		if (super.modelServerSocket.getReturnCode().isEmpty() == false) {
			for (int returnCodeModel : super.modelServerSocket.getReturnCode()) {
				if (returnCodeModel != 100) {
					super.addReturnCode(returnCodeModel);
				}
			}
		}

		// Splitting the text to obtain informations
		if (super.errorReturnCode == false) {
			texteContentCut();
		}

		// If the logins exits, then the mail can be saved
		if (super.errorReturnCode == false) {
			writeMessage();
		}

	}

	/**
	 * Splitting the text to obtain the addressee, the object, the message, the id
	 * and the password
	 */
	private void texteContentCut() {
		super.log.trace("Sever - Proccessing the checking steps before writing the mail ");

		// Checking only once the logins
		if (super.checkLogins == false) {
			super.sql = ControlSql.instance(log);

		} else {
			super.sql = null;
		}

		getInfos();

		if (super.loginID.isBlank() == true & super.loginPassword.isEmpty() == true) {
			super.addReturnCode(65);

		} else {
			super.log.trace("Sever - starting to ckeck the logins ");
			// Check if the logins exist in the database once
			if (super.checkLogins == false) {
				super.sql.find(loginID, loginPassword);
				super.checkLogins = true;

				if (super.sql.returnCode != 100) {
					super.addReturnCode(sql.getReturnCode());
				}
			}

		}

	}// -

	/**
	 * 
	 * @param separatorSigne
	 * @return logins
	 */
	private void getInfos() {
		String[] tabs;
		int numberOfDivision;

		tabs = null;

		if (super.texteContent.contains(separatorSigne)) {
			tabs = super.texteContent.split(separatorSigne);
			if (tabs == null) {
				super.addReturnCode(60);

			} else {
				// Calculating the number of blocks
				numberOfDivision = 0;
				for (int i = 0; i < tabs.length; i++) {
					numberOfDivision++;
				}

				// The mail is composed of 5 blocks, addressee, object, and message, ID, and
				// password (not written in the mail)
				if (numberOfDivision == 5) {
					// All the verifications passed

					// ID
					super.loginID = tabs[3];
					// password
					super.loginPassword = tabs[4];
					// addressee
					super.addressee = tabs[0];
					// object
					super.object = tabs[1];
					// message
					super.message = tabs[2];

				} else {
					super.addReturnCode(61);
				}

			}

		} else {
			super.addReturnCode(63);
		}

	}

	/**
	 * Write the mail
	 */
	private void writeMessage() {
		Writing writer;

		writer = new Writing(super.addressee, super.object, super.message, super.loginID);
		super.addReturnCode(writer.writingMail(super.loginID, path));

	}

}// END PRG
