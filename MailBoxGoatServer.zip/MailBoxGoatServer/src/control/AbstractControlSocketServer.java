package control;

import java.net.InetAddress;
import java.util.List;

import org.apache.logging.log4j.Logger;

import model.ModelServerSocket;

public abstract class AbstractControlSocketServer {
	protected ModelServerSocket modelServerSocket;
	protected ControlSql sql;
	protected InetAddress url;
	protected String addressee, object, message, loginID, loginPassword, texteContent;
	protected boolean errorReturnCode, checkLogins;
	protected Logger log;
	protected List<Integer> returnCode;

	// Getters & Setters :
	protected void setReturnCode(List<Integer> returnCode) {
		this.returnCode = returnCode;
	}

	protected String getAddressee() {
		return addressee;
	}

	protected void setAddressee(String addressee) {
		this.addressee = addressee;
	}

	protected String getObject() {
		return object;
	}

	protected void setObject(String object) {
		this.object = object;
	}

	protected String getMessage() {
		return message;
	}

	protected void setMessage(String message) {
		this.message = message;
	}

	protected String getLoginID() {
		return loginID;
	}

	protected void setLoginID(String loginID) {
		this.loginID = loginID;
	}

	protected String getLoginPassword() {
		return loginPassword;
	}

	protected void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	protected String getTexteContent() {
		return texteContent;
	}

	protected void setTexteContent(String texteContent) {
		this.texteContent = texteContent;
	}

	protected boolean isCheckLogins() {
		return checkLogins;
	}

	protected void setCheckLogins(boolean checkLogins) {
		this.checkLogins = checkLogins;
	}

	protected boolean isErrorReturnCode() {
		return errorReturnCode;
	}

	protected void setErrorReturnCode(boolean errorReturnCode) {
		this.errorReturnCode = errorReturnCode;
	}

	public Logger getLogger() {
		return log;
	}

	protected void setLogger(Logger logger) {
		this.log = logger;
	}

	/**
	 * 
	 * @param code
	 */
	protected void addReturnCode(int code) {
		if (code < 99) {
			// Error detected
			this.errorReturnCode = true;
		}
		this.returnCode.add(code);
	}

}// END PRG
