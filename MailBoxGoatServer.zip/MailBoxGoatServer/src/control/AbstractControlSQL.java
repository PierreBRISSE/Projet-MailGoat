package control;

import org.apache.logging.log4j.Logger;

public abstract class AbstractControlSQL {
	protected Logger logger;
	protected int returnCode;

	// Getters & Setters
	public int getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(int returnCode) {
		this.returnCode = returnCode;
	}

	public Logger getLogger() {
		return logger;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}

}// END PRG
