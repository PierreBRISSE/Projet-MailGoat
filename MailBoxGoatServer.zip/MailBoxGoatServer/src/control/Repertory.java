package control;

public interface Repertory {
	static final String path = "C:\\Users\\Pierre\\Desktop\\Projet alpha\\Java\\repertoireSocket\\";
	static final int port = 8080;
	static final int timeout = 900000;
	static final String separatorSigne="###";
	
}// END PRG
