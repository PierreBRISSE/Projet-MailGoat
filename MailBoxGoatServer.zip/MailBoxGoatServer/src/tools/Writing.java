package tools;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.time.Instant;

public class Writing extends AbstractWriting {

	public Writing(String content) {
		super();
		setReturnCode(100);
		setContent(content);
		setAdresse("");
		setFile(new File(super.adresse));
	}

	public Writing(String content, File file) {
		super();
		setReturnCode(100);
		setContent(content);
		setAdresse(file.getAbsolutePath());
		setFile(file);
	}

	public Writing(String content, String adresse) {
		super();
		setReturnCode(100);
		setContent(content);
		setAdresse(adresse);
		setFile(new File(super.adresse));
	}

	public Writing(String addressee, String obj, String message, String id) {
		super();
		setReturnCode(100);
		setAddresse(addressee);
		setObject(obj);
		setMessage(message);
	}

	// *****************
	// Writing methods
	// *****************
	/**
	 * 
	 * @return returnCode
	 */
	public int writingFile() {
		if (super.file.exists()) {

			if (super.content.isBlank() == false) {
				writing();

			} else {
				super.returnCode = 25;
			}

		} else {
			try {
				super.file.createNewFile();
			} catch (Exception e) {
				super.returnCode = 26;
			}
		}

		return super.returnCode;
	}

	// ---------------------------
	// Methods for writing a mail
	/**
	 * 
	 * @param texteMail
	 * @param path
	 */
	public int writingMail(String id, String pathFile) {
		String addresseePara, objectPara, idPara;
		int numberResponse;

		addresseePara = "";
		objectPara = "";
		idPara = "";

		// Recovering the addressee
		if (super.addresse.substring(0, 4).equalsIgnoreCase("null")) {
			addresseePara = super.addresse;
			addresseePara = addresseePara.replace("null", "");

		} else {
			addresseePara = super.addresse;
		}

		// Recovering the object
		objectPara = super.object;

		// Recovering the ID
		idPara = id;

		// Text mail
		super.content = mailTexteCreation(super.message, addresseePara, idPara);

		// Creating the file
		super.adresse = pathFile + objectPara + ".txt";
		super.file = new File(super.adresse);

		if (super.file.exists() == false) {
			// The file does not exist
			writing();

		} else {
			// The file exist and we have to add a numeral to differentiate
			numberResponse = 0;
			do {
				numberResponse++;
				super.adresse = pathFile + objectPara + numberResponse + ".txt";
				super.file = new File(super.adresse);

			} while (super.file.exists() == true);
			writing();

		}

		return super.returnCode;

	}

	/**
	 * 
	 * @param core
	 * @param addresseePara
	 * @param idPara
	 * @return message
	 */
	private String mailTexteCreation(String core, String addresseePara, String idPara) {
		StringBuilder messageBuilder;
		String newLine, newLineSpace;
		Instant instant;

		messageBuilder = new StringBuilder();
		newLine = "\n";
		newLineSpace = newLine + newLine;
		instant = Instant.now();

		messageBuilder.append("TO : ");
		messageBuilder.append(addresseePara);
		messageBuilder.append(newLineSpace);
		messageBuilder.append(core);
		messageBuilder.append(newLineSpace);
		messageBuilder.append("Best Regard,");
		messageBuilder.append(newLine);
		messageBuilder.append(idPara);
		messageBuilder.append(newLineSpace);
		messageBuilder.append(instant.toString().subSequence(0, 10));
		messageBuilder.append(newLine);
		messageBuilder.append(instant.toString().subSequence(11, 19));

		return messageBuilder.toString();
	}

	/**
	 * common method for writing
	 */
	private void writing() {
		BufferedWriter bufferedWriter;

		try (FileOutputStream fileOutStream = new FileOutputStream(super.file);) {
			bufferedWriter = new BufferedWriter(new OutputStreamWriter(fileOutStream));
			bufferedWriter.write(super.content);
			bufferedWriter.flush();

			bufferedWriter.close();

		} catch (Exception e) {
			super.returnCode = 27;
		}

	}// -

}// END PRG
