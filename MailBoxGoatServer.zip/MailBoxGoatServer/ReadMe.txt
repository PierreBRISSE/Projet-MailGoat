This program is a professional demonstration.
So it is normal, that some methods are unused.
The program is made to evolute.

The program is the server part of a mailbox.
The communication between the client and the server parts, is done by webService.
Before starting, please modify the parameters in "Repertory".

The UML of the program can be found in the file Diagram.

Pierre BRISSE 2020-10-04.